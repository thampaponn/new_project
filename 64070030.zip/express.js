const express = require('express')
const { date } = require('joi')
const app = express()
const port = 3000

const pool = require("./config/database")

app.use(express.json())
app.use(express.urlencoded({extended: false}))

app.get('/todo', async (req, res, next) => {
  //res.send('GET ToDo List')

  let start_date = req.query.start_date
  let end_date = req.query.end_date

  console.log(start_date)

  try {

    const [rows, fields] = await pool.query("SELECT *, DATE_FORMAT(due_date, '%Y-%m-%d') AS due_date FROM todo WHERE due_date >= ? and due_date <= ?", [start_date, end_date]);
    console.log(rows.length)

    if (rows.length > 0) {
      res.status(200).send(rows)
    } 

  } catch (err) {
    console.log(err)
  }

})

app.post('/todo', async (req, res, next) => {
  //res.send('POST create a new ToDo')

  const title = req.body.title;
  const description = req.body.description;
  const due_date = req.body.due_date;

  console.log(due_date)
  try {

    if (title === "") {
      res.status(400).json({message: "ต้องกรอก title"})
    }
    else if (description === "") {
      res.status(400).json({message: "ต้องกรอก description"})
    }
    else {

      if (due_date === "") {

        const [row1, column1] = await pool.query("INSERT INTO todo(title, description, due_date, `order`) VALUES(?, ?, CURRENT_TIMESTAMP, 1)", [title, description])
      }
      else {
        const [row2, column2] = await pool.query("INSERT INTO todo(title, description, due_date, `order`) VALUES(?, ?, ?, 1)", [title, description, due_date])
        console.log(row2)

        res.status(200).json({
        message: "สร้าง ToDo " + title + " สำเร็จ", todo : row2}
      )
      }

    }

  } catch (err) {
    console.log(err)
        return next(err);
  }
})

app.get('/todo/:id', async (req, res, next) => {
  try {
    const [rows, fields] = await pool.query("SELECT * FROM todo WHERE id=?", [req.params.id])
    res.json(rows[0])
  } catch (err) {
    console.log(err)
    next(err)
  }
})

app.delete('/todo/:id', async (req, res, next) => {
  //res.send(`DELETE a ToDo with id = ${req.params.id}`)

  try {

    const [rows, fields] = await pool.query("SELECT * FROM todo");
    console.log(rows.length)

    if (rows.length < req.params.id) {
      res.status(400).json({"message": "ไม่พบข้อมูล ToDo ที่ต้องการลบ"});
    }
    else {
      await pool.query('DELETE FROM todo WHERE id=?;', [req.params.id]) // delete blog
      res.json({ message: 'ลบ ToDo ' + req.params.id + ' สำเร็จ' })
    }
    
  } catch (err) {
    console.log(err)
  } 
})

module.exports = app